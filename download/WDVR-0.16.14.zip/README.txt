WDVR 0.16.14 - Watch Dogs (2014) VR mod
=======================================

INSTALL
1. Extract this zip INTO your Watch Dogs folder (the folder that contains bin\Watch_Dogs.exe).
   You should end up with:
     bin\dinput8.dll              (Ultimate ASI Loader)
     bin\plugins\WDVR.asi         (the mod)
     bin\plugins\openvr_api.dll   (SteamVR library)
2. Start SteamVR, then the game.
3. In game press INSERT (keyboard) and tick "VR on (game in the headset)".
4. Look straight ahead, press numpad 5 to recenter.
5. Once: press Ctrl+F11 and hold a T-pose (arms out to the sides) to calibrate the arms.

Requires: Watch Dogs (2014) PC (tested: Ubisoft Connect version), SteamVR, HTC Vive + wands.
Full guide, controls and troubleshooting: https://github.com/Somney/WDVR

UNINSTALL: delete bin\plugins\WDVR.asi (and bin\dinput8.dll if no other mod uses it).
Only keep ONE .asi copy of WDVR in bin\plugins.
